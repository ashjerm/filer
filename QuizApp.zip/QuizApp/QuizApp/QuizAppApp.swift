//
//  QuizAppApp.swift
//  QuizApp
//
//  Created by Porridge on 5/6/21.
//

import SwiftUI

@main
struct QuizAppApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
